var count = 1;
while (count < 10)
count++;
console.log(count)